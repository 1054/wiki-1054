		<div id="footer">
			<p><a href="http://creativecommons.org/licenses/by-sa/2.5/" rel="license" title="licence Creative Commons"><img src="<?php echo DOKU_TPL; ?>images/button_cc.gif" alt="licence Creative Commons"/></a> Sauf indication, tous les textes et sources sont sous licence <a class="external" href="http://creativecommons.org/licenses/by-sa/2.5/" rel="license" title="licence Creative Commons">Creative Commons</a>.</p>
			<p>
				<a href="mailto:webmaster@neolao.com" title="Me contacter"><img src="<?php echo DOKU_TPL; ?>images/button_mail.png" alt="Contact" /></a>
				<a href="<?php echo DOKU_BASE; ?>feed.php" title="<?php echo $lang['btn_recent']; ?>"><img src="<?php echo DOKU_TPL; ?>images/button_rss.png" alt="<?php echo $lang['btn_recent']; ?>" /></a>
				<a href="?do=export_raw" title="Source"><img src="<?php echo DOKU_TPL; ?>images/button_raw.png" alt="Source" /></a>
				<a href="http://wiki.splitbrain.org/wiki:dokuwiki" title="Propulsé par DokuWiki"><img src="<?php echo DOKU_TPL; ?>images/button_dw.png" alt="Propulsé par DokuWiki" /></a>
				Avatar créé par <a class="external" href="http://www.zookeeper.fr/">dod</a>.
			</p>
		</div>
	</body>
</html>