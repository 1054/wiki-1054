<ul>
			<li>
				<?php tpl_link(wl("php"),"PHP"); ?>
				<ul class="children">
					<li><?php tpl_link(wl("php:classes"),"Classes"); ?></li>
					<li><?php tpl_link(wl("php:dokuwiki"),"DokuWiki"); ?></li>
					<li><?php tpl_link(wl("php:punbb"),"PunBB"); ?></li>
					<li><?php tpl_link(wl("php:apo"),"APO"); ?></li>
					<li><?php tpl_link(wl("php:webmanager"),"Web Manager"); ?></li>
				</ul>
			</li>
			<li>
				<?php tpl_link(wl("flash"),"Flash"); ?>
				<ul class="children">
					<li><?php tpl_link(wl("flash:classes"),"Classes FP7"); ?></li>
					<li><?php tpl_link(wl("flash:classes_fp8"),"Classes FP8"); ?></li>
					<li><?php tpl_link(wl("flash:components"),"Composants"); ?></li>
				</ul>
			</li>
			<li>
				<?php tpl_link(wl("javascript"),"Javascript"); ?>
				<ul class="children">
					<li><?php tpl_link(wl("javascript:ajax"),"AJAX"); ?></li>
				</ul>
			</li>
			<li>
				<?php tpl_link(wl("miscellaneous"),"Autres"); ?>
			</li>
		</ul>